# Origen upstream

- Repositorio: https://github.com/John-K/pspdecrypt.git
- Rama: `master`
- Commit: `c156627db7634d395c380c0a9589130f603307fc`
- Fecha: 2024-06-07 («Merge pull request #52 from wally4000/master»)
- Estado del árbol local al copiar: limpio (`git status --porcelain` vacío).

## Cómo verificar/obtener el upstream

```sh
git clone https://github.com/John-K/pspdecrypt.git
cd pspdecrypt
git checkout c156627db7634d395c380c0a9589130f603307fc
```

La copia de `upstream/` de este paquete es ese árbol **sin** `.git`; no se ha
modificado ningún fichero de `upstream/` (los cambios están en
`modifications/`).

## Licencia

GPLv3. Texto íntegro en `LICENSE.TXT` (idéntico al `LICENSE.TXT` del upstream).
