# Fuente correspondiente — `libkon_pspdecrypt.so` (APK 0.2.0, SHA-256 4788…BBB)

Paquete autocontenido de la fuente **completa y correspondiente** del ejecutable
GPLv3 `lib/arm64-v8a/libkon_pspdecrypt.so` (5.785.648 B, SHA-256
`cdad619e1b068735c5b893e4226784bcbf32c098c79a9d97fbc8a86cb5fd3bdb`) que
redistribuye la APK `KOn-Houkago-Live-Recompiled-0.2.0-android.apk`
(85.029.657 B, SHA-256 `4788D64C…BBB`).

`pspdecrypt` es un programa independiente: no se enlaza con `libkon_runtime.so`
ni con el APK; se ejecuta aparte para descifrar `EBOOT.BIN`.

## Contenido

```
upstream/            árbol upstream completo (John-K/pspdecrypt @ c156627), sin .git
modifications/       fuentes exactas que produjeron el binario (recorte ~PSP/PRX)
modifications/NOTICE.txt   qué se cambió y por qué
tools/build_portable.py    receta de build (portable, sin rutas personales)
tools/build_android.sh     envoltorio con variables de entorno
LICENSE.TXT          GPLv3 (texto íntegro)
UPSTREAM.md          origen, commit y cómo obtenerlo/verificarlo
ATTRIBUTIONS.md      autoría y aviso de modificación (GPLv3 §5a)
VERIFICATION.md      correspondencia con el binario distribuido y hash de la reconstrucción
SHA256SUMS.txt       hashes de todos los ficheros del paquete
```

## Reconstruir

Requisitos: Python 3.8+, NDK 28.2.13676358 (`ANDROID_NDK_HOME`).

```sh
python3 tools/build_portable.py --abi arm64 \
  --upstream ./upstream --out ./build-out \
  --ndk "$ANDROID_NDK_HOME"
```

Salida: `build-out/pspdecrypt-arm64`. Con NDK 28.2 y `--abi arm64` el resultado
es **byte a byte idéntico** al binario distribuido (ver `VERIFICATION.md`).

`--abi x86_64` produce la variante x86_64 (no distribuida en esta APK).

## Qué se recortó (resumen)

- Se conserva solo la ruta `~PSP`/PRX (`pspDecryptPRX`).
- Fuera PSAR, IPL y, con ellos, OpenSSL (`<openssl/des.h>`, `<openssl/sha.h>`).
- CLI nueva y mínima (`pspdecrypt__main`): `EBOOT.BIN -o salida.elf`.
- Sin cambios en la criptografía de libkirk ni en `PrxDecrypter.cpp`.

Detalle exacto en `modifications/NOTICE.txt`.

## Límites

- Verificado: compilación reproducible byte a byte con NDK 28.2 en Windows; el
  binario es ELF64 AArch64 PIE con NEEDED solo bionic (`libz`, `libm`, `libdl`,
  `libc`) e intérprete `/system/bin/linker64`.
- **No** se ha ejecutado en hardware ARM en este entorno (sí en el emulador
  x86_64 con la variante x86_64, que descifró el EBOOT de prueba con el hash
  esperado). No se afirma nada más allá de eso.
- Este paquete no crea `APPROVED.txt` ni declara cumplimiento global de la APK.
