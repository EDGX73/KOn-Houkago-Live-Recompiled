# Verificación de correspondencia binario ↔ fuente

## Binario distribuido

| elemento | bytes | SHA-256 |
|---|---|---|
| `lib/arm64-v8a/libkon_pspdecrypt.so` dentro de la APK `4788…BBB` | 5.785.648 | `cdad619e1b068735c5b893e4226784bcbf32c098c79a9d97fbc8a86cb5fd3bdb` |
| `work/codegen_android/bin/pspdecrypt-arm64` (artefacto de build) | 5.785.648 | idéntico |

Comprobado leyendo la entrada del ZIP de la APK y comparándola byte a byte con el
artefacto: **iguales**.

## Reconstrucción desde este paquete

```
python3 tools/build_portable.py --abi arm64 --upstream ./upstream \
  --out ./build-out --ndk <NDK 28.2.13676358>
→ build-out/pspdecrypt-arm64  5.785.648 B
  sha256=cdad619e1b068735c5b893e4226784bcbf32c098c79a9d97fbc8a86cb5fd3bdb
```

**Bit a bit idéntico** al binario distribuido, con el mismo NDK (28.2.13676358)
y las mismas opciones. Dos compilaciones independientes (la del artefacto y la
de este paquete) coinciden, así que el build es determinista con este toolchain.

## Propiedades del ELF (del binario distribuido)

- ELF64, `ET_DYN` (PIE), Machine **AArch64**.
- Intérprete: `/system/bin/linker64`.
- `NEEDED`: `libz.so`, `libm.so`, `libdl.so`, `libc.so` (solo bionic; sin
  OpenSSL, sin `libc++_shared`).
- Exporta `main`; no exporta símbolos del runtime del port.

## Límites

- La identidad bit a bit está demostrada con **NDK 28.2.13676358 en Windows**.
  Otro NDK/versión de clang puede producir un binario distinto (misma función,
  distinto código). No se afirma identidad con otros toolchains.
- No se ha ejecutado la variante arm64 en hardware ARM en este entorno. La
  variante x86_64 del mismo código descifró el `EBOOT.BIN` de prueba en el
  emulador con el tamaño y SHA-256 esperados (4.019.288 B, `eda890…85b1`).
- Este documento no certifica el cumplimiento global de la APK.
