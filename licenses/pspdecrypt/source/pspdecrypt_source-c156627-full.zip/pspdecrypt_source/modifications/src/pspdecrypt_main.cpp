// Trimmed pspdecrypt CLI: ~PSP/PRX only (EBOOT.BIN -> decrypted ELF).
// Derived from pspdecrypt.cpp (GPLv3); PSAR/IPL options removed.
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <fstream>
#include <vector>
#include "PrxDecrypter.h"
#include "CommonTypes.h"

static const unsigned ELF_MAGIC = 0x464C457Fu;
static const unsigned PSP_MAGIC = 0x5053507Eu;

static void usage(const char* exe) {
    std::printf("Usage: %s <EBOOT.BIN> -o <out.elf>\n", exe);
}

int main(int argc, char** argv) {
    const char* in = nullptr;
    const char* out = nullptr;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "-o") && i + 1 < argc) out = argv[++i];
        else if (!std::strcmp(argv[i], "-h") || !std::strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
        else if (argv[i][0] != '-' && !in) in = argv[i];
        else { std::fprintf(stderr, "unknown argument: %s\n", argv[i]); return 2; }
    }
    if (!in) { usage(argv[0]); return 2; }
    std::ifstream f(in, std::ios::binary | std::ios::ate);
    if (!f) { std::fprintf(stderr, "could not open %s\n", in); return 1; }
    const std::streamoff n = f.tellg();
    if (n < 0x30) { std::fprintf(stderr, "input too small\n"); return 1; }
    std::vector<unsigned char> data(static_cast<size_t>(n)), dec(static_cast<size_t>(n) + 0x1000);
    f.seekg(0);
    f.read(reinterpret_cast<char*>(data.data()), n);
    unsigned magic = 0;
    std::memcpy(&magic, data.data(), 4);
    const unsigned char* result = data.data();
    int written = 0;
    if (magic == ELF_MAGIC) {
        written = static_cast<int>(data.size());
    } else if (magic == PSP_MAGIC) {
        written = pspDecryptPRX(data.data(), dec.data(), static_cast<u32>(data.size()), nullptr, true);
        if (written <= 0) { std::fprintf(stderr, "PRX decryption failed (%d)\n", written); return 4; }
        result = dec.data();
    } else {
        std::fprintf(stderr, "not a ~PSP file\n");
        return 3;
    }
    const char* path = out ? out : "out.elf";
    std::ofstream o(path, std::ios::binary | std::ios::trunc);
    if (!o) { std::fprintf(stderr, "could not write %s\n", path); return 1; }
    o.write(reinterpret_cast<const char*>(result), written);
    std::printf("%s: %d bytes -> %s\n", in, written, path);
    return 0;
}
