# Atribuciones y licencia

## Programa

- `pspdecrypt`: https://github.com/John-K/pspdecrypt.git, commit
  `c156627db7634d395c380c0a9589130f603307fc`. Autores y contribuidores del
  proyecto upstream (ver `upstream/Readme.md` y el historial del repositorio).
- Licencia: **GNU General Public License v3**. Texto íntegro en `LICENSE.TXT`
  (idéntico al del upstream).

## Modificaciones

- Derivado recortado a la ruta `~PSP`/PRX para Android (2026-10-28), descrito en
  `modifications/NOTICE.txt`; cumple el aviso de modificación de GPLv3 §5a.
- El binario resultante es un **programa separado**. No se enlaza con
  `libkon_runtime.so`, `libkon_probe.so` ni con el resto del APK.

## Cómo debe acompañarse

Si se redistribuye el binario, debe ir con:

1. Este paquete de fuente (o el ZIP `pspdecrypt_source-c156627-full.zip`) o una
   oferta escrita válida (GPLv3 §6), y
2. el texto de la licencia (`LICENSE.TXT`),

tal como exige GPLv3. El empaquetador de la APK debe incluir ambos en
`assets/toolchain/SOURCES/` y `assets/licenses/`.
