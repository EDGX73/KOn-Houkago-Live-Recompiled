#!/bin/sh
# Reconstruye el ejecutable Android desde esta fuente.
# Uso: ANDROID_NDK_HOME=/ruta/ndk ./tools/build_android.sh [arm64|x86_64]
set -e
: "${ANDROID_NDK_HOME:?define ANDROID_NDK_HOME}"
ABI="${1:-arm64}"
cd "$(dirname "$0")/.."
python3 tools/build_portable.py --abi "$ABI" --upstream ./upstream \
  --out ./build-out --ndk "$ANDROID_NDK_HOME"
