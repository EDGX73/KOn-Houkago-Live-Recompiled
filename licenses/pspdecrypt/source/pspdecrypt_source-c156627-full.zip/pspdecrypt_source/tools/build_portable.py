#!/usr/bin/env python3
"""Reproduce libkon_pspdecrypt.so (trimmed pspdecrypt) for Android.

This is the portable version of tools/make_pspdecrypt.py (the script actually
used for the APK). It stages the trimmed sources from the pristine upstream
tree, compiles with the Android NDK and links with libc++ static.

Usage:
  python3 build_portable.py --upstream ./upstream --out ./build-out \
      --ndk $ANDROID_NDK_HOME --abi arm64

No absolute paths are baked in: the output binary depends only on the compiler,
the flags and the sources.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

API = 29
CPP = ["common.cpp", "PrxDecrypter.cpp", "pspdecrypt_lib.cpp"]
C = ["libLZR.c", "kl4e.c",
     "libkirk/AES.c", "libkirk/amctrl.c", "libkirk/bn.c", "libkirk/ec.c",
     "libkirk/kirk_engine.c", "libkirk/SHA1.c"]
HEADERS = ["common.h", "CommonTypes.h", "Swap.h", "PrxDecrypter.h", "pspdecrypt_lib.h",
           "libLZR.h", "kl4e.h",
           "libkirk/AES.h", "libkirk/amctrl.h",
           "libkirk/kirk_engine.h", "libkirk/SHA1.h"]

MAIN = r'''// Trimmed pspdecrypt CLI: ~PSP/PRX only (EBOOT.BIN -> decrypted ELF).
// Derived from pspdecrypt.cpp (GPLv3); PSAR/IPL options removed.
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <fstream>
#include <vector>
#include "PrxDecrypter.h"
#include "CommonTypes.h"

static const unsigned ELF_MAGIC = 0x464C457Fu;
static const unsigned PSP_MAGIC = 0x5053507Eu;

static void usage(const char* exe) {
    std::printf("Usage: %s <EBOOT.BIN> -o <out.elf>\n", exe);
}

int main(int argc, char** argv) {
    const char* in = nullptr;
    const char* out = nullptr;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "-o") && i + 1 < argc) out = argv[++i];
        else if (!std::strcmp(argv[i], "-h") || !std::strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
        else if (argv[i][0] != '-' && !in) in = argv[i];
        else { std::fprintf(stderr, "unknown argument: %s\n", argv[i]); return 2; }
    }
    if (!in) { usage(argv[0]); return 2; }
    std::ifstream f(in, std::ios::binary | std::ios::ate);
    if (!f) { std::fprintf(stderr, "could not open %s\n", in); return 1; }
    const std::streamoff n = f.tellg();
    if (n < 0x30) { std::fprintf(stderr, "input too small\n"); return 1; }
    std::vector<unsigned char> data(static_cast<size_t>(n)), dec(static_cast<size_t>(n) + 0x1000);
    f.seekg(0);
    f.read(reinterpret_cast<char*>(data.data()), n);
    unsigned magic = 0;
    std::memcpy(&magic, data.data(), 4);
    const unsigned char* result = data.data();
    int written = 0;
    if (magic == ELF_MAGIC) {
        written = static_cast<int>(data.size());
    } else if (magic == PSP_MAGIC) {
        written = pspDecryptPRX(data.data(), dec.data(), static_cast<u32>(data.size()), nullptr, true);
        if (written <= 0) { std::fprintf(stderr, "PRX decryption failed (%d)\n", written); return 4; }
        result = dec.data();
    } else {
        std::fprintf(stderr, "not a ~PSP file\n");
        return 3;
    }
    const char* path = out ? out : "out.elf";
    std::ofstream o(path, std::ios::binary | std::ios::trunc);
    if (!o) { std::fprintf(stderr, "could not write %s\n", path); return 1; }
    o.write(reinterpret_cast<const char*>(result), written);
    std::printf("%s: %d bytes -> %s\n", in, written, path);
    return 0;
}
'''


def trim_lib(text: str) -> str:
    text = text.replace('#include <openssl/des.h>\n', '')
    text = text.replace('#include "ipl_decrypt.h"\n', '')
    start = text.index('int pspDecryptIPL1(')
    end = text.index('int pspIsCompressed(')
    text = text[:start] + text[end:]
    start = text.index('static void DecryptT(')
    text = text[:start]
    leftover = [w for w in ('DES_', 'openssl', 'ipl_decrypt', 'pspDecryptTable', 'decryptIPL') if w in text]
    if leftover:
        raise SystemExit(f"trim failed, still references: {leftover}")
    return text


def stage(upstream: Path, work: Path) -> None:
    if work.exists():
        shutil.rmtree(work)
    (work / "libkirk").mkdir(parents=True)
    for name in HEADERS:
        shutil.copy2(upstream / name, work / name)
    for name in ("common.cpp", "PrxDecrypter.cpp"):
        shutil.copy2(upstream / name, work / name)
    (work / "pspdecrypt_lib.cpp").write_text(
        trim_lib((upstream / "pspdecrypt_lib.cpp").read_text(encoding="utf8")), encoding="utf8")
    (work / "pspdecrypt_main.cpp").write_text(MAIN, encoding="utf8")
    for name in ("libLZR.c", "kl4e.c"):
        shutil.copy2(upstream / name, work / name)
    for name in C:
        if name.startswith("libkirk/"):
            shutil.copy2(upstream / name, work / name)


def toolchain(ndk: Path) -> Path:
    pre = ndk / "toolchains" / "llvm" / "prebuilt"
    for host in ("windows-x86_64", "linux-x86_64", "darwin-x86_64"):
        if (pre / host / "bin").is_dir():
            return pre / host / "bin"
    raise SystemExit(f"no NDK prebuilt toolchain under {pre}")


def exe(bin_dir: Path, name: str) -> Path:
    p = bin_dir / name
    if (bin_dir / f"{name}.exe").is_file():
        return bin_dir / f"{name}.exe"
    return p


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def run(args) -> None:
    p = subprocess.run([str(a) for a in args], capture_output=True, text=True)
    if p.returncode:
        raise SystemExit(f"{args[0]} failed:\n{p.stdout}\n{p.stderr}")


def build(ndk: Path, abi: str, work: Path, out: Path) -> Path:
    triple = {"x86_64": "x86_64-linux-android", "arm64": "aarch64-linux-android"}[abi]
    bin_dir = toolchain(ndk)
    cc, cxx = exe(bin_dir, "clang"), exe(bin_dir, "clang++")
    obj_dir = out / "obj" / abi
    if obj_dir.exists():
        shutil.rmtree(obj_dir)
    obj_dir.mkdir(parents=True)
    common = [f"--target={triple}{API}", "-O2", "-DNDEBUG", "-fPIE", "-I", work]
    objs = []
    for name in C:
        o = obj_dir / (name.replace('/', '_').replace('.c', '.o'))
        run([cc, *common, "-c", work / name, "-o", o])
        objs.append(o)
    for name in CPP:
        o = obj_dir / name.replace('.cpp', '.o')
        run([cxx, *common, "-std=c++17", "-fno-exceptions", "-fno-rtti", "-c", work / name, "-o", o])
        objs.append(o)
    o = obj_dir / "pspdecrypt_main.o"
    run([cxx, *common, "-std=c++17", "-fno-exceptions", "-fno-rtti", "-c", work / "pspdecrypt_main.cpp", "-o", o])
    objs.append(o)
    binary = out / f"pspdecrypt-{abi}"
    run([cxx, *common, "-pie", "-static-libstdc++", "-o", binary, *objs, "-lz"])
    return binary


def main(argv) -> int:
    ap = argparse.ArgumentParser()
    here = Path(__file__).resolve().parent
    ap.add_argument("--upstream", default=str(here.parent / "upstream"))
    ap.add_argument("--out", default=str(here.parent / "build-out"))
    ap.add_argument("--ndk", default=None)
    ap.add_argument("--abi", default="arm64", choices=["x86_64", "arm64", "all"])
    args = ap.parse_args(argv)
    ndk = Path(args.ndk or __import__("os").environ.get("ANDROID_NDK_HOME", ""))
    if not ndk or not ndk.is_dir():
        raise SystemExit("pass --ndk or set ANDROID_NDK_HOME")
    out = Path(args.out)
    work = out / "src"
    out.mkdir(parents=True, exist_ok=True)
    stage(Path(args.upstream), work)
    abis = ["x86_64", "arm64"] if args.abi == "all" else [args.abi]
    for abi in abis:
        b = build(ndk, abi, work, out)
        print(f"{abi}: {b} {b.stat().st_size} bytes sha256={sha256(b)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
